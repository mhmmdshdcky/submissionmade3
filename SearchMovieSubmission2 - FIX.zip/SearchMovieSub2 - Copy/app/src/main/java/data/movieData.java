package data;

import android.graphics.Movie;

import com.anakblogger.searchmoviesub2.movie;

import java.util.ArrayList;

public class movieData {
    public static String[][] data = new String[][]{
            {"Bumblebee", "Release pada tahun 2018"," Film Sekuel dari transformers", "https://upload.wikimedia.org/wikipedia/en/thumb/7/77/Bumblebee_%28film%29_poster.png/220px-Bumblebee_%28film%29_poster.png"},
            {"Aquaman","Release pada tahun 2018", "Film dari Justice League.", "https://i.redd.it/mioxrsm1sma11.jpg"},
            {"Creed II", "Release pada tahun 2018", "Film pertarungan tinju profesional","https://m.media-amazon.com/images/M/MV5BMTcxMjUwNjQ5N15BMl5BanBnXkFtZTgwNjk4MzI4NjM@._V1_UX182_CR0,0,182,268_AL_.jpg"},
            {"The Mule", "Release pada tahun 2018", "Film mengisahkan seorang kakek yang ingin membalas waktu yang terbuang bersama keluarga dengan menjadi kurir narkoba", "https://m.media-amazon.com/images/M/MV5BMTc1OTc5NzA4OF5BMl5BanBnXkFtZTgwOTAzMzE2NjM@._V1_UY1200_CR90,0,630,1200_AL_.jpg"},
            {"Dragon Ball", "Release pada tahun 2018", "Film petualangan dan pertarungan untuk mencari bola naga", "https://upload.wikimedia.org/wikipedia/en/thumb/7/74/Dragon_Ball_Super_Key_visual.jpg/220px-Dragon_Ball_Super_Key_visual.jpg"},
            {"Terlalu Tampan", "Release pada tahun 2019", "Film mengisahkan seorang remaja sekolah yang tampan", "https://m.media-amazon.com/images/M/MV5BYWFjNzMyNWUtMzYyOS00OTE5LWJjMzktN2U2YzVjZGM1MDgxXkEyXkFqcGdeQXVyOTc0NDkxNDU@._V1_SY1000_SX800_AL_.jpg"}
            };

    public static ArrayList<movie> getListData(){
        ArrayList<movie> list = new ArrayList<>();
        for (String[] aData : data) {
            movie movie = new movie();
            movie.setName(aData[0]);
            movie.setRelease(aData[1]);
            movie.setDeskripsi(aData[2]);
            movie.setPhoto(aData[3]);
            list.add(movie);
        }
        return list;
    }
}
