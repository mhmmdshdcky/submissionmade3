package data;

import com.anakblogger.searchmoviesub2.movie;

import java.util.ArrayList;

public class comingsoonData {
    public static String[][] data = new String[][]{
            {"Toy Story 4", "Release pada tahun 2019"," Film Sekuel dari toy story", "https://lrmonline.com/file/2019/02/DypjzpvUUAAaqbw.jpg-large.jpeg"},
            {"Pikachu The Movie","Release pada tahun 2019", "Film petualangan pikachu", "https://m.media-amazon.com/images/M/MV5BMTk1MjgwNjM2MV5BMl5BanBnXkFtZTgwMzMyODM3NjM@._V1_.jpg"},
            {"Captain Marvel", "Release pada tahun 2019", "Film Marvel terbaru yang bercerita tentang seorang wanita yang menyelamatkan dunia","https://i.redd.it/x2bbgg3h63r11.jpg"},
            {"Avengers End Game", "Release pada tahun 2019", "Film mengisahkan pertarungan para Avengers melawan Thanos", "https://thumbor.forbes.com/thumbor/fit-in/640x434/filters%3Aformat%28jpg%29/https%3A%2F%2Fblogs-images.forbes.com%2Fmarkhughes%2Ffiles%2F2018%2F12%2FAVENGERS-ENDGAME-poster-1-1200x1777.jpg"},
            {"Dilan 1991", "Release pada tahun 2019", "Film sekuel lanjutan dari film sebelumnya Dilan 1990", "https://cdn.brilio.net/news/2018/11/10/154799/945460-editan-poster-dilan-1991-.jpg"},
            {"Avatar 2", "Release pada tahun 2019", "Film sekuel dari lanjutan film Avatar, yang mengisahkan seorang manusia lumpuh yang menjadi seorang Avatar yang tangguh", "https://i.pinimg.com/originals/e3/32/34/e332345715162cbbeeee9f29a495d3fe.jpg"}
    };

    public static ArrayList<movie> getListData(){
        ArrayList<movie> list = new ArrayList<>();
        for (String[] aData : data) {
            movie movie = new movie();
            movie.setName(aData[0]);
            movie.setRelease(aData[1]);
            movie.setDeskripsi(aData[2]);
            movie.setPhoto(aData[3]);
            list.add(movie);
        }
        return list;
    }
}
