package fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.anakblogger.searchmoviesub2.DetailActivity;
import com.anakblogger.searchmoviesub2.ItemClickSupport;
import com.anakblogger.searchmoviesub2.R;
import com.anakblogger.searchmoviesub2.movie;

import java.util.ArrayList;

import adapter.MoviesAdapter;
import data.movieData;

public class NowplayingFragment extends Fragment {
    static final String EXTRAS_MOVIE = "EXTRAS_MOVIE";

    private RecyclerView rvCategory;
    private ArrayList<movie> list = new ArrayList<>();

    public static NowplayingFragment newInstance()
    {
        return new NowplayingFragment();
    }
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView=inflater.inflate(R.layout.fragment_nowplaying,null);

        rvCategory = (RecyclerView) rootView.findViewById(R.id.rv_category);
        rvCategory.setHasFixedSize(true);

        list.addAll(movieData.getListData());

        showRecyclerList();

        return rootView;
    }

    private void showRecyclerList() {
        rvCategory.setLayoutManager(new LinearLayoutManager(getActivity()));
        MoviesAdapter listMovieAdapter = new MoviesAdapter(getActivity());
        listMovieAdapter.setListMovie(list);
        rvCategory.setAdapter(listMovieAdapter);

        ItemClickSupport.addTo(rvCategory).setOnItemClickListener(new ItemClickSupport.OnItemClickListener() {
            @Override
            public void onItemClicked(RecyclerView recyclerView, int position, View v) {
                showSelectedMovie(list.get(position));
            }
        });
    }

    private void showSelectedMovie(movie mMovieItems) {

        movie mMovieItem1 = new movie();
        mMovieItem1.setName(mMovieItems.getName());
        mMovieItem1.setDeskripsi(mMovieItems.getDeskripsi());
        mMovieItem1.setPhoto(mMovieItems.getPhoto());
        mMovieItem1.setRelease(mMovieItems.getRelease());
        Intent move = new Intent(getActivity(), DetailActivity.class);
        move.putExtra(DetailActivity.EXTRA_ITEMS, mMovieItem1);
        startActivity(move);
    }

    @Override
    public String toString() {
        return "NowPlaying";
    }
}
