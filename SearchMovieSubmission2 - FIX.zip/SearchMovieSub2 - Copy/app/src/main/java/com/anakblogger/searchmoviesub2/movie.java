package com.anakblogger.searchmoviesub2;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONObject;

public class movie implements Parcelable{
    private String name, deskripsi, photo, release;
    private int id;

    public movie() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }



    public movie(JSONObject object){
        try {
            Integer id = object.getInt("id");
            String name = object.getString("original_title");
            String release = object.getString("release_date");
            String overview = object.getString("overview");
            String posterpath = object.getString("poster_path");


            this.id = id;
            this.name = name;
            this.release = release;
            this.deskripsi = overview;
            this.photo = posterpath;



        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.name);
        dest.writeString(this.deskripsi);
        dest.writeString(this.photo);
        dest.writeString(this.release);
        dest.writeInt(this.id);
    }

    protected movie(Parcel in) {
        this.name = in.readString();
        this.deskripsi = in.readString();
        this.photo = in.readString();
        this.release = in.readString();
        this.id = in.readInt();
    }

    public static final Creator<movie> CREATOR = new Creator<movie>() {
        @Override
        public movie createFromParcel(Parcel source) {
            return new movie(source);
        }

        @Override
        public movie[] newArray(int size) {
            return new movie[size];
        }
    };
}
