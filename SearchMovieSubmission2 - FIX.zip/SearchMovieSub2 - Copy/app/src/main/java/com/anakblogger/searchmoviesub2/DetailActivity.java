package com.anakblogger.searchmoviesub2;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.method.ScrollingMovementMethod;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class DetailActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    CircleImageView profileCircleImageView;
    String profileImageUrl = "https://lh3.googleusercontent.com/-4qy2DfcXBoE/AAAAAAAAAAI/AAAAAAAABi4/rY-jrtntAi4/s640-il/photo.jpg";

    DrawerLayout drawer;
    Toolbar toolbar;
    ActionBarDrawerToggle toggle;


    public static final String EXTRA_JUDUL = "EXTRA_JUDUL";
    public static final String EXTRA_DESKRIPSI = "EXTRA_DESKRIPSI";
    public static final String EXTRA_RELEASE = "EXTRA_RELEASE";
    public static final String EXTRA_GAMBAR = "EXTRA_GAMBAR";
    public static String EXTRA_ITEMS = "extra_items";

    private String judul;
    private String deskripsi;
    private String release;
    private String gambar;
    private Context context;

    TextView txtJudul;
    TextView txtDeskripsi;
    TextView txtRelease;
    ImageView imgGambar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);

        txtJudul = findViewById(R.id.txtJudul);
        txtDeskripsi = findViewById(R.id.txtDeskripsi);
        txtRelease = findViewById(R.id.txtRelease);
        imgGambar = findViewById(R.id.imgGambar);

        txtDeskripsi.setMovementMethod(new ScrollingMovementMethod());

        // judul = getIntent().getStringExtra(EXTRA_JUDUL);
        // deskripsi = getIntent().getStringExtra(EXTRA_DESKRIPSI);
        // release = getIntent().getStringExtra(EXTRA_RELEASE);
        // gambar = getIntent().getStringExtra(EXTRA_GAMBAR);
        movie mMovieItems = getIntent().getParcelableExtra(EXTRA_ITEMS);
        String judul = mMovieItems.getName();
        String tahun = mMovieItems.getRelease();
        String overview = mMovieItems.getDeskripsi();
        String poster = mMovieItems.getPhoto();

        txtJudul.setText(judul);
        txtDeskripsi.setText(overview);
        txtRelease.setText(tahun);
        Picasso.get().load(poster).into(imgGambar);

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        return false;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
