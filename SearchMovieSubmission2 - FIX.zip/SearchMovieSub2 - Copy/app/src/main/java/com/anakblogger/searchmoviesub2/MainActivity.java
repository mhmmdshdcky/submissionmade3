package com.anakblogger.searchmoviesub2;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import adapter.MovieAdapter;
import de.hdodenhof.circleimageview.CircleImageView;
import fragment.ComingsoonFragment;
import fragment.NowplayingFragment;
import items.MovieItems;
import loader.MyAsyncTaskLoader;

public class MainActivity extends AppCompatActivity implements android.app.LoaderManager.LoaderCallbacks<ArrayList<MovieItems>>, View.OnClickListener, NavigationView.OnNavigationItemSelectedListener {
    CircleImageView profileCircleImageView;
    String profileImageUrl = "https://lh3.googleusercontent.com/-4AYOQqZg3do/AAAAAAAAAAI/AAAAAAAAB9k/-w7Bqt_GT5c/w511-h512-p-rw/photo.jpg";

    DrawerLayout drawer;
    Toolbar toolbar;
    ActionBarDrawerToggle toggle;
    MovieAdapter adapter;
    ImageView imgGambar;

    static final String EXTRAS_MOVIE = "EXTRAS_MOVIE";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.toolbar);
        FragmentManager mFragmentManager = getSupportFragmentManager();
        FragmentTransaction mFragmentTransaction = mFragmentManager.beginTransaction();
        NowplayingFragment mHomeFragment = new NowplayingFragment();
        Fragment fragment = mFragmentManager.findFragmentByTag(NowplayingFragment.class.getSimpleName());
        if (!(fragment instanceof NowplayingFragment)) {
            mFragmentTransaction.add(R.id.containerID, mHomeFragment, NowplayingFragment.class.getSimpleName());
            Log.d("MyFlexibleFragment", "Fragment Name :" + NowplayingFragment.class.getSimpleName());
            mFragmentTransaction.commit();

            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null)
                getSupportActionBar().setTitle(getString(R.string.nowplaying));
            drawer = findViewById(R.id.drawer_layout);
            NavigationView navigationView = findViewById(R.id.nav_view);
            navigationView.setNavigationItemSelectedListener(this);
            profileCircleImageView = navigationView.getHeaderView(0).findViewById(R.id.imageView);
            Glide.with(MainActivity.this)
                    .load(profileImageUrl)
                    .into(profileCircleImageView);

            adapter = new MovieAdapter(this);
            adapter.notifyDataSetChanged();
            // listView = (ListView) findViewById(R.id.listView);

            imgGambar = findViewById(R.id.imgGambar);

        }
    }

    @Override
    public android.content.Loader<ArrayList<MovieItems>> onCreateLoader(int id, Bundle args) {

        String kumpulanFilm = "";
        if (args != null) {
            kumpulanFilm = args.getString(EXTRAS_MOVIE);
        }

        return new MyAsyncTaskLoader(this, kumpulanFilm);
    }

    @Override
    public void onLoadFinished(android.content.Loader<ArrayList<MovieItems>> loader, ArrayList<MovieItems> data) {
        adapter.setData(data);
    }

    @Override
    public void onLoaderReset(android.content.Loader<ArrayList<MovieItems>> loader) {
        adapter.setData(null);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.pengaturan_bahasa:
                Intent mIntent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
                startActivity(mIntent);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }

    @Override
    protected void onPause() {
        super.onPause();
        drawer.removeDrawerListener(toggle);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        Fragment fragment = null;
        Class fragmentClass = null;
        String title = "";
        if (id == R.id.nav_nowplaying) {
            if (getSupportActionBar() != null)
                getSupportActionBar().setTitle(getString(R.string.nowplaying));
            MainActivity.this.getSupportFragmentManager().beginTransaction().replace(R.id.containerID, NowplayingFragment.newInstance()).commit();
        } else if (id == R.id.nav_comingsoon) {
            if (getSupportActionBar() != null)
                getSupportActionBar().setTitle(getString(R.string.comingsoon));
            MainActivity.this.getSupportFragmentManager().beginTransaction().replace(R.id.containerID, ComingsoonFragment.newInstance()).commit();
            }
            DrawerLayout drawer = findViewById(R.id.drawer_layout);
            drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
