package loader;

import android.content.Context;
import android.text.TextUtils;

import com.anakblogger.searchmoviesub2.BuildConfig;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.SyncHttpClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;
import items.MovieItems;

public class MyAsyncTaskLoader extends android.content.AsyncTaskLoader<ArrayList<MovieItems>> {
    private ArrayList<MovieItems> mData;
    private boolean mHasHasil = false;

    private String mKumpulanMovie;

    public MyAsyncTaskLoader(final Context context,String mKumpulanMovie) {
        super(context);

        onContentChanged();
        this.mKumpulanMovie = mKumpulanMovie;
    }

    @Override
    protected void onStartLoading() {
        if (takeContentChanged())
            forceLoad();
        else if (mHasHasil)
            deliverResult(mData);
    }

    @Override
    public void deliverResult(final ArrayList<MovieItems> data) {
        mData = data;
        mHasHasil = true;
        super.deliverResult(data);
    }

    @Override
    protected void onReset() {
        super.onReset();
        onStopLoading();
        if (mHasHasil) {
            onReleaseResources(mData);
            mData = null;
            mHasHasil = false;
        }
    }
    
    @Override
    public ArrayList<MovieItems> loadInBackground() {
        SyncHttpClient client = new SyncHttpClient();

        String url;
        if (TextUtils.isEmpty(mKumpulanMovie)) {
            url = "https://api.themoviedb.org/3/movie/now_playing?api_key=" + BuildConfig.TMDB_API_KEY;
        } else {
            url = "https://api.themoviedb.org/3/search/movie?api_key=" + BuildConfig.TMDB_API_KEY + "&language=en-US&query=" + mKumpulanMovie;
        }

        final ArrayList<MovieItems> filmItemses = new ArrayList<>();

        client.get(url, new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
                setUseSynchronousMode(true);
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                try {
                    String result = new String(responseBody);
                    JSONObject responseObject = new JSONObject(result);
                    JSONArray list = responseObject.getJSONArray("results");

                    for (int i = 0 ; i < result.length() ; i++){
                        JSONObject movie = list.getJSONObject(i);
                        MovieItems movieItems = new MovieItems(movie);
                        filmItemses.add(movieItems);
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });

        return filmItemses;
    }

    protected void onReleaseResources(ArrayList<MovieItems> data) {

    }
}
