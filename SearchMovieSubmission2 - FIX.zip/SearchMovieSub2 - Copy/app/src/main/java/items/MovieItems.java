package items;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MovieItems {
    private int id;
    private String nama;
    private String deskripsi;
    private String releaseTgl;
    private String gambar;
    private Date releaseMovie;
    private SimpleDateFormat eemmmdyyyy;
    private SimpleDateFormat yyyymmdd;
    String deskripsiAwal;

    public  MovieItems(JSONObject object){
        eemmmdyyyy = new SimpleDateFormat("EE, MMM d, yyyy", Locale.getDefault());
        yyyymmdd = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        try {
            String url = "http://image.tmdb.org/t/p/w342";
            int id = object.getInt("id");
            String nama = object.getString("title");
            String deskripsi = object.getString("overview");
            String releaseTgl = object.getString("release_date");
            String gambar = url + object.getString("poster_path");
            releaseMovie = yyyymmdd.parse(releaseTgl);
            releaseTgl = eemmmdyyyy.format(releaseMovie);
            String deskripsiAwal = deskripsi.substring(0, 60) + "...";
            this.id = id;
            this.nama = nama;
            this.deskripsi = deskripsi;
            this.releaseTgl = releaseTgl;
            this.gambar = gambar;
            this.deskripsiAwal = deskripsiAwal;
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public String getNama() {
        return nama;
    }


    public String getDeskripsi() {
        return deskripsi;
    }

    public String getReleaseTgl() {
        return releaseTgl;
    }


    public String getGambar() {
        return gambar;
    }


    public String getDeskripsiAwal() {
        return deskripsiAwal;
    }

}
